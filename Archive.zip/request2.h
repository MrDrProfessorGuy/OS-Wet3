//
// Created by guy cohen on 05/06/2022.
//

#ifndef WET_REQUEST2_H
#define WET_REQUEST2_H
#include "Worker.h"
void requestHandle(int fd, BadWorker& worker);



#endif //WET_REQUEST2_H
