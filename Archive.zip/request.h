#ifndef __REQUEST_H__

void requestHandle(int fd);

#endif
